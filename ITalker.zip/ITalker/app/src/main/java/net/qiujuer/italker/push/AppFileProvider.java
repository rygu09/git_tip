package net.qiujuer.italker.push;

import android.support.v4.content.FileProvider;

/**
 * Android7 FileProvider 适配
 */
public class AppFileProvider extends FileProvider {
}