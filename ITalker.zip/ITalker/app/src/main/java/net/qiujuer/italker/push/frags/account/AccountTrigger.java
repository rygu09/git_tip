package net.qiujuer.italker.push.frags.account;

/**
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public interface AccountTrigger {
    void triggerView();
}
